import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateReviewReply = async (reviewText: string, sentiment: 'positive' | 'negative' | 'neutral', businessName: string): Promise<string> => {
  if (!process.env.API_KEY) {
    // Fallback if no API key is present for the demo UI to function visually
    return new Promise(resolve => setTimeout(() => {
      resolve(`[Demo Mode - No API Key] Thank you for your feedback about ${businessName}. We are glad to hear your experience was ${sentiment === 'positive' ? 'excellent' : 'important to us'}. We work every day to improve.`);
    }, 1500));
  }

  try {
    const prompt = `
      Act as a professional and friendly business owner named "${businessName}".
      Write a short, empathetic, and personalized reply for the following Google review.
      
      The review is: "${reviewText}"
      The detected sentiment is: ${sentiment}.

      If it is negative, offer a solution or contact info. If it is positive, thank them and invite them back.
      Keep the tone professional but approachable. Max 50 words.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    return response.text || "Could not generate a reply at this moment.";
  } catch (error) {
    console.error("Error generating reply:", error);
    return "There was an error connecting to the AI. Please try again.";
  }
};