import React from 'react';
import { ShieldCheck, TrendingUp, Smartphone, Clock, Award, Users } from 'lucide-react';

const Features: React.FC = () => {
  return (
    <section id="features" className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-base font-bold text-emerald-600 tracking-wide uppercase mb-2">Key Features</h2>
          <h3 className="text-3xl md:text-5xl font-bold text-slate-900 mb-6">Everything you need to dominate Google Maps</h3>
          <p className="text-lg text-slate-600">Stop chasing customers for reviews. Our system automates the entire process ethically and effectively.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          {/* Card 1: Reputation Shield (Large) */}
          <div className="md:col-span-2 bg-white rounded-3xl p-8 border border-slate-100 shadow-lg hover:shadow-xl transition-shadow relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity">
              <ShieldCheck size={120} className="text-emerald-600" />
            </div>
            <div className="relative z-10">
              <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center mb-6">
                <ShieldCheck className="text-emerald-600" size={24} />
              </div>
              <h4 className="text-2xl font-bold text-slate-900 mb-3">Reputation Shield</h4>
              <p className="text-slate-600 mb-6 max-w-md">
                We intercept negative reviews before they go public. Unhappy customers are directed to a private feedback form, giving you the chance to fix the issue.
              </p>
              <div className="bg-slate-50 rounded-lg p-4 border border-slate-100 inline-block">
                <div className="flex items-center gap-3">
                  <div className="h-2 w-24 bg-slate-200 rounded-full overflow-hidden">
                    <div className="h-full bg-red-500 w-[10%]"></div>
                  </div>
                  <span className="text-xs text-slate-500 font-medium">Negatives filtered</span>
                </div>
                <div className="flex items-center gap-3 mt-2">
                  <div className="h-2 w-24 bg-slate-200 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-500 w-[90%]"></div>
                  </div>
                  <span className="text-xs text-slate-500 font-medium">Positives published</span>
                </div>
              </div>
            </div>
          </div>

          {/* Card 2: QR & Automation */}
          <div className="bg-slate-900 rounded-3xl p-8 text-white relative overflow-hidden">
             <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-emerald-500 rounded-full blur-3xl opacity-30"></div>
             <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center mb-6 backdrop-blur-sm">
                <Smartphone className="text-emerald-400" size={24} />
              </div>
              <h4 className="text-xl font-bold mb-3">Automated Requests</h4>
              <p className="text-slate-300 text-sm leading-relaxed">
                Send requests via SMS, Email, or WhatsApp right after purchase. Or use our smart QR codes at your counter.
              </p>
          </div>

          {/* Card 3: Analytics */}
          <div className="bg-white rounded-3xl p-8 border border-slate-100 shadow-lg hover:shadow-xl transition-shadow">
            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mb-6">
              <TrendingUp className="text-blue-600" size={24} />
            </div>
            <h4 className="text-xl font-bold text-slate-900 mb-3">Real-time Analytics</h4>
            <p className="text-slate-600 text-sm">
              Visualize your reputation growth. Understand which days you get more reviews and what aspects your clientele values most.
            </p>
          </div>

          {/* Card 4: Multi-platform */}
          <div className="bg-white rounded-3xl p-8 border border-slate-100 shadow-lg hover:shadow-xl transition-shadow">
            <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mb-6">
              <Users className="text-purple-600" size={24} />
            </div>
            <h4 className="text-xl font-bold text-slate-900 mb-3">Multi-location</h4>
            <p className="text-slate-600 text-sm">
              Have more than one location? Manage all your venues from a single centralized dashboard.
            </p>
          </div>

           {/* Card 5: AI Response (Highlight) */}
           <div className="bg-emerald-600 rounded-3xl p-8 text-white md:col-span-1 shadow-lg shadow-emerald-200">
             <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center mb-6 backdrop-blur-sm">
              <Clock className="text-white" size={24} />
            </div>
            <h4 className="text-xl font-bold mb-3">Save 10 hours/week</h4>
            <p className="text-emerald-100 text-sm">
              Our AI responds to 100% of your reviews in seconds, improving your local SEO and customer trust.
            </p>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Features;