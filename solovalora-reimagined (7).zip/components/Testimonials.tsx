import React from 'react';

const Testimonials: React.FC = () => {
  const logos = [
    { name: "BurgerKing", color: "bg-orange-500" }, 
    { name: "LocalClinic", color: "bg-blue-500" }, 
    { name: "DentalPlus", color: "bg-teal-500" }, 
    { name: "FitGym", color: "bg-slate-800" }, 
    { name: "UrbanSpa", color: "bg-purple-500" }
  ];

  return (
    <section id="testimonials" className="py-20 bg-white border-t border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <p className="text-center text-slate-500 font-semibold mb-8 uppercase tracking-widest text-xs">Trusted by over 500 businesses</p>
        
        <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16 mb-20 opacity-70 grayscale hover:grayscale-0 transition-all duration-500">
           {/* Placeholder Logos simulating real clients instead of Amazon/Airbnb */}
           {logos.map((logo, idx) => (
             <div key={idx} className="flex items-center gap-2 font-bold text-xl text-slate-700">
               <div className={`w-8 h-8 rounded-full ${logo.color}`}></div>
               {logo.name}
             </div>
           ))}
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-slate-50 p-8 rounded-2xl border border-slate-100 hover:shadow-lg transition-shadow">
              <div className="flex text-yellow-400 mb-4">★★★★★</div>
              <p className="text-slate-700 mb-6 italic">"Since using SoloValora, our positive reviews have tripled. The best part is I no longer have to worry about manually replying every night."</p>
              <div className="flex items-center gap-4">
                <img src={`https://picsum.photos/50/50?random=${i}`} alt="User" className="w-10 h-10 rounded-full object-cover" />
                <div>
                  <p className="font-bold text-slate-900 text-sm">Carlos Mendoza</p>
                  <p className="text-xs text-slate-500">Restaurant Owner</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;