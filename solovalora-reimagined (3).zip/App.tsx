import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import InteractiveDemo from './components/InteractiveDemo';
import Testimonials from './components/Testimonials';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <main>
        <Hero />
        <Testimonials />
        <Features />
        <InteractiveDemo />
        
        {/* Simple Pricing Teaser Section */}
        <section id="pricing" className="py-20 bg-emerald-900 text-white text-center">
          <div className="max-w-4xl mx-auto px-4">
            <h2 className="text-3xl font-bold mb-6">Start growing today</h2>
            <p className="text-emerald-200 mb-8 text-lg">Join hundreds of businesses that have already automated their success.</p>
            <button className="bg-white text-emerald-900 px-8 py-4 rounded-full font-bold hover:bg-emerald-50 transition-colors shadow-lg hover:shadow-xl transform hover:-translate-y-1 duration-300">
              View Plans & Pricing
            </button>
            <p className="mt-4 text-sm text-emerald-300 opacity-80">14-day free trial · No commitment</p>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default App;