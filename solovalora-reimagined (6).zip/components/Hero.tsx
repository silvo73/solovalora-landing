import React from 'react';
import { CheckCircle, Star, ArrowRight, Zap } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
      {/* Background Blobs */}
      <div className="absolute top-0 right-0 -mr-20 -mt-20 w-[500px] h-[500px] bg-emerald-100/50 rounded-full blur-3xl opacity-70 animate-pulse"></div>
      <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-[400px] h-[400px] bg-blue-100/50 rounded-full blur-3xl opacity-70"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
          
          {/* Text Content */}
          <div className="flex-1 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-100 text-emerald-700 text-xs font-bold uppercase tracking-wider mb-6">
              <Star size={12} fill="currentColor" /> New Generative AI v3.0
            </div>
            
            <h1 className="text-4xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.1] mb-6">
              Turn reviews into <br/>
              <span className="gradient-text">real growth</span>
            </h1>
            
            <p className="text-lg text-slate-600 mb-8 leading-relaxed max-w-2xl mx-auto lg:mx-0">
              Automate your reputation management on Google. Get <strong>300% more reviews</strong>, filter negative feedback, and auto-respond with human-sounding AI.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-10">
              <button className="bg-emerald-600 text-white px-8 py-4 rounded-xl text-lg font-bold hover:bg-emerald-700 transition-all shadow-xl shadow-emerald-500/20 hover:scale-105 flex items-center justify-center gap-2 group">
                Start Free Trial
                <ArrowRight className="group-hover:translate-x-1 transition-transform" size={20} />
              </button>
              <button className="bg-white text-slate-700 border border-slate-200 px-8 py-4 rounded-xl text-lg font-bold hover:bg-slate-50 transition-all hover:border-slate-300 flex items-center justify-center">
                Watch Demo
              </button>
            </div>

            <div className="flex items-center justify-center lg:justify-start gap-6 text-sm text-slate-500 font-medium">
              <div className="flex items-center gap-2">
                <CheckCircle size={16} className="text-emerald-500" /> No credit card required
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle size={16} className="text-emerald-500" /> Cancel anytime
              </div>
            </div>
          </div>

          {/* Visual Asset */}
          <div className="flex-1 w-full max-w-[600px] lg:max-w-none relative">
            <div className="relative">
              {/* Main App Mockup Card */}
              <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 p-6 relative z-20 transform transition-transform hover:-translate-y-2 duration-500">
                <div className="flex justify-between items-center mb-6 border-b border-slate-100 pb-4">
                  <div>
                    <h3 className="font-bold text-slate-800">Aroma Coffee Shop</h3>
                    <div className="flex text-yellow-400 text-sm">★★★★★ <span className="text-slate-400 ml-2 font-normal">(4.9)</span></div>
                  </div>
                  <div className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded font-bold">Verified</div>
                </div>
                
                <div className="space-y-4">
                  {/* Fake Review Item */}
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="w-8 h-8 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center font-bold text-xs">MA</div>
                      <div>
                        <p className="text-sm font-bold text-slate-900">Mary Allen</p>
                        <p className="text-xs text-slate-500">2 hours ago</p>
                      </div>
                    </div>
                    <p className="text-sm text-slate-600 mb-3">"Amazing service! The coffee was delicious and the atmosphere is perfect for working. I'll definitely be back."</p>
                    
                    <div className="pl-4 border-l-2 border-emerald-500 mt-2">
                      <p className="text-xs text-emerald-600 font-bold mb-1 flex items-center gap-1"><Zap size={12}/> AI Generated Response</p>
                      <p className="text-sm text-slate-700 italic">"Thanks Mary! We love knowing you enjoyed the coffee and the space. Hope to see you working with us again soon. ☕"</p>
                    </div>
                  </div>
                </div>

                {/* Floating Elements */}
                <div className="absolute -right-12 top-20 bg-white p-4 rounded-xl shadow-xl border border-slate-100 animate-[bounce_3s_infinite]">
                  <div className="flex items-center gap-3">
                    <div className="bg-emerald-100 p-2 rounded-lg">
                      <Star className="text-emerald-600" size={20} fill="currentColor"/>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 uppercase font-bold">New Reviews</p>
                      <p className="text-xl font-bold text-slate-900">+128%</p>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Decorative shapes behind */}
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-gradient-to-tr from-emerald-200 to-blue-200 rounded-full opacity-20 blur-2xl -z-10"></div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Hero;