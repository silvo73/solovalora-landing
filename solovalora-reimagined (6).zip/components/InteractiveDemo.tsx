import React, { useState } from 'react';
import { generateReviewReply } from '../services/gemini';
import { Sparkles, MessageSquare, Loader2, Copy, RefreshCw } from 'lucide-react';

const InteractiveDemo: React.FC = () => {
  const [reviewInput, setReviewInput] = useState("The food was okay, but the service was a bit slow. We waited 20 minutes for the check.");
  const [generatedReply, setGeneratedReply] = useState("");
  const [loading, setLoading] = useState(false);
  const [businessType, setBusinessType] = useState("Restaurant");

  const handleGenerate = async () => {
    setLoading(true);
    setGeneratedReply("");
    
    // Simple sentiment logic for demo purposes
    const sentiment = reviewInput.toLowerCase().includes('slow') || reviewInput.toLowerCase().includes('bad') || reviewInput.toLowerCase().includes('terrible') ? 'negative' : 'positive';
    
    const reply = await generateReviewReply(reviewInput, sentiment, `My ${businessType}`);
    setGeneratedReply(reply);
    setLoading(false);
  };

  return (
    <section id="demo" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Try the AI Magic</h2>
          <p className="text-slate-600 max-w-2xl mx-auto">
            Don't just take our word for it, try it yourself. Paste a typical review and watch Solovalora generate the perfect reply in seconds.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 lg:gap-12 items-start">
          
          {/* Input Side */}
          <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 shadow-sm">
            <div className="flex justify-between items-center mb-4">
              <label className="text-sm font-bold text-slate-700 uppercase tracking-wide">1. Paste a customer review</label>
              <select 
                value={businessType}
                onChange={(e) => setBusinessType(e.target.value)}
                className="text-xs bg-white border border-slate-300 rounded-md px-2 py-1 outline-none focus:border-emerald-500"
              >
                <option value="Restaurant">Restaurant</option>
                <option value="Dental Clinic">Dental Clinic</option>
                <option value="Hotel">Hotel</option>
                <option value="Store">Retail Store</option>
              </select>
            </div>
            
            <textarea
              value={reviewInput}
              onChange={(e) => setReviewInput(e.target.value)}
              className="w-full h-40 p-4 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none resize-none text-slate-700 text-base"
              placeholder="Ex: I loved the place but..."
            />
            
            <div className="mt-4 flex justify-end">
              <button 
                onClick={handleGenerate}
                disabled={loading || !reviewInput}
                className={`flex items-center gap-2 px-6 py-3 rounded-lg font-bold text-white transition-all ${loading ? 'bg-slate-400 cursor-not-allowed' : 'bg-slate-900 hover:bg-emerald-600 hover:shadow-lg'}`}
              >
                {loading ? <Loader2 className="animate-spin" size={20}/> : <Sparkles size={20}/>}
                {loading ? 'Generating...' : 'Generate Reply'}
              </button>
            </div>
          </div>

          {/* Output Side */}
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl transform rotate-1 opacity-20"></div>
            <div className="relative bg-white p-6 rounded-2xl border border-slate-200 shadow-xl min-h-[300px] flex flex-col">
              <div className="flex items-center gap-3 mb-6 pb-4 border-b border-slate-100">
                <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center">
                  <MessageSquare className="text-emerald-600" size={20} />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900">Suggested Reply</h3>
                  <p className="text-xs text-slate-500">Optimized for SEO and loyalty</p>
                </div>
              </div>

              <div className="flex-1 flex items-center justify-center">
                {loading ? (
                  <div className="text-center">
                     <div className="inline-block w-8 h-8 border-4 border-emerald-200 border-t-emerald-600 rounded-full animate-spin mb-4"></div>
                     <p className="text-slate-400 animate-pulse">Analyzing sentiment and writing...</p>
                  </div>
                ) : generatedReply ? (
                  <div className="w-full">
                    <p className="text-lg text-slate-800 leading-relaxed font-medium">"{generatedReply}"</p>
                  </div>
                ) : (
                  <div className="text-center text-slate-400">
                    <Sparkles className="mx-auto mb-2 opacity-50" size={40} />
                    <p>The reply will appear here</p>
                  </div>
                )}
              </div>

              {generatedReply && (
                <div className="mt-6 pt-4 border-t border-slate-100 flex justify-between items-center">
                  <div className="flex gap-2">
                    <button className="p-2 hover:bg-slate-100 rounded-md text-slate-500 transition-colors" title="Regenerate" onClick={handleGenerate}>
                      <RefreshCw size={18} />
                    </button>
                  </div>
                  <button className="flex items-center gap-2 text-sm font-bold text-emerald-600 hover:text-emerald-700 transition-colors">
                    <Copy size={16} /> Copy text
                  </button>
                </div>
              )}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default InteractiveDemo;